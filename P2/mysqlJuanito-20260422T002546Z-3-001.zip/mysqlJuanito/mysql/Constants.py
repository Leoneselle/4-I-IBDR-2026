from cryptography.fernet import Fernet
import base64

class Constants:
    e_host = 'Z0FBQUFBQnAzXzVzekg5d1JiYWJFSERHSE1EYnF0SG1vb3REa2RiNy1YZkJDX19Vem15QUI4OTdmOTV5Y1ptT1FZY2hpSF9BMkVPZ2M3LVdIckc3VlFPSUtOQ1E2RV9rODRZOU90bm5IR05hakIzN3otN0loQTdEcE8xOTU2eTBBSFlOZGo3ZlBic1E='
    e_port = 'Z0FBQUFBQnAzXzVzbEZ6RU1iNHlrV0h2WHBOVnFJbzJzZDFXZWhXbnRlWmthY1pkMDl2VjR1VVc3YWE2Sms2Mm5oZlM3eXhZVjU3RmZEbDNPdDdXSDdOUG1lWFVGU09ta2c9PQ=='
    e_database = 'Z0FBQUFBQnAzXzVzbUR1TDBmOTNrbE5VcnRDcFVtcFBxZl9MdHRvdGxsQkdOQ3BleVBWQjhHcl90UndHWk8wbU1LbC13anRXcFRiWXZmQ29DNEFZLUFKRUJGLW9nQjhOalE9PQ=='
    e_user = 'Z0FBQUFBQnAzXzVzc0VrcVYtanF0SzBlV3BqS29UakVJaklGQnFDZHFjUVNoQzQydnEzdHEwQTZ0Sms3QlNfZVcyOVZkUy1zTVBGV3hzV2VKaXpYdXdxdTcybE1Fc3JoX2c9PQ=='
    e_password = 'Z0FBQUFBQnAzXzVzRzhNbXNVT2d2U1FWNzdvaUJOU25UR3VjWXlqX3ZNSlNQUms3ay11NTJPTkYxVTkzNk1NNVFuR0x5WGtXaDV0YmtaX01GMzJOeWhwZHBjcVJaRGhWNVp4ajFrVS1BeWVrZFBpUmo2X3RyTlE9'

    host = "mysql-a6275ed-cbtis-761e.g.aivencloud.com"
    port = "18946"
    database = "defaultdb"
    user = "avnadmin"
    password  = "AVNS_39icJ_BLj3Xobgk1Xsd"
    

    def generate_and_save_key(self, key_filename="secret.key"):
        """Generates a key and saves it to a file."""
        key = Fernet.generate_key()
        with open(key_filename, "wb") as key_file:
            key_file.write(key)
        print(f"New key generated and saved to {key_filename}")

    def load_key(self, key_filename="secret.key"):
        """Loads the key from the current directory's file."""
        return open(key_filename, "rb").read()
    
    
    def encrypt(self, string):
        # You only need to run this once to create the key file
        #self.generate_and_save_key() 
        # Load the key from the file
        key = self.load_key()
        f = Fernet(key)
        # Strings must be encoded to bytes before encryption
        encoded_string = string.encode()
        # Encrypt the bytes
        encrypted_bytes = f.encrypt(encoded_string)
        # The result is bytes, often stored or transmitted as a base64 encoded string
        return base64.urlsafe_b64encode(encrypted_bytes).decode('utf-8')

    def decrypt(self, string):
        key = self.load_key()
        f = Fernet(key)
        encoded_string = string.encode()
        decrypted_bytes = f.decrypt(base64.urlsafe_b64decode(encoded_string).decode('utf-8'))
        return decrypted_bytes.decode()


const = Constants()
print(f"e_host = '{const.encrypt(Constants.host)}'")
print(f"e_port = '{const.encrypt(Constants.port)}'")
print(f"e_database = '{const.encrypt(Constants.database)}'")
print(f"e_user = '{const.encrypt(Constants.user)}'")
print(f"e_password = '{const.encrypt(Constants.password)}'")
"""
print(f"Original Host : {const.decrypt(Constants.e_host)}")
print(f"Original Port : {const.decrypt(Constants.e_port)}")
print(f"Original Database : {const.decrypt(Constants.e_database)}")
print(f"Original User : {const.decrypt(Constants.e_user)}")
print(f"Original password : {const.decrypt(Constants.e_password)}")
"""
